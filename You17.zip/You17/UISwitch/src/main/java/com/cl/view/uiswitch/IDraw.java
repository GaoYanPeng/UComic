package com.cl.view.uiswitch;

import android.graphics.Canvas;

/**
 * Created by phenixchen on 2016/1/12.
 */
public interface IDraw {
    void draw(Canvas canvas);
}
