package com.lanou3g.you17.search;

import com.lanou3g.you17.R;
import com.lanou3g.you17.base.BaseFragment;

/**
 * Created by dllo on 16/8/26.
 */
public class SearchFragment extends BaseFragment {
    @Override
    protected int initLayout() {
        return R.layout.search_fragment;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
