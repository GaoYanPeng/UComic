package com.lanou3g.you17.tools;

/**
 * Created by dllo on 16/8/27.
 */
public class API {
    public static final String API_SIGN ="http://web.app.u17.com/activity/2.html?";
}