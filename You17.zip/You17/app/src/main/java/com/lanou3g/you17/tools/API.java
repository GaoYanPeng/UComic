package com.lanou3g.you17.tools;

/**
 * Created by dllo on 16/8/27.
 */
public class API {
    public static final String API_SIGN ="http://web.app.u17.com/activity/2.html?";
    //搜索界面下层GridView接口
    public static final String API_SEARCH_GRIDVIEW="http://app.u17.com/v3/appV3/android/phone/sort/list?android_id=3d6f8f613d878af1&v=3110099&model=Google+Nexus+5+-+4.4.4+-+API+19+-+1080x1920&come_from=openqq";
    //搜索界面热门搜索下的推荐
    public static final String API_TOP_SEARCH_URL="http://app.u17.com/v3/appV3/android/phone/search/hotkeywords?android_id=3d6f8f613d878af1&v=3110099&model=Google+Nexus+5+-+4.4.4+-+API+19+-+1080x1920&t=1472626633&come_from=openqq";
    //搜索界面下层GridView详情接口
    public static final String API_SEARCH_GRIDVIEW_DETAILS="http://app.u17.com/v3/appV3/android/phone/list/commonComicList?argValue=5&argName=theme&argCon=2&page=1&android_id=3d6f8f613d878af1&v=3110099&model=Google+Nexus+5+-+4.4.4+-+API+19+-+1080x1920&come_from=openqq";
}